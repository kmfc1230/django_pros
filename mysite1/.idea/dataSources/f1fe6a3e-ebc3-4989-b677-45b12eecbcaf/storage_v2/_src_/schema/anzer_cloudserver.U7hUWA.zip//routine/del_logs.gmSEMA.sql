create
    definer = root@`%` procedure del_logs()
begin
	DELETE FROM tb_log_status  where DATE_FORMAT(add_time,'%Y%m%d')< DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 DAY),'%Y%m%d');
  DELETE FROM tb_log_sensors  where DATE_FORMAT(add_time,'%Y%m%d')< DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 DAY),'%Y%m%d');
  DELETE FROM tb_log_task  where DATE_FORMAT(add_time,'%Y%m%d')< DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 DAY),'%Y%m%d') ;
  DELETE FROM tb_log_event  where DATE_FORMAT(add_time,'%Y%m%d')< DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL 1 DAY),'%Y%m%d');
end;

